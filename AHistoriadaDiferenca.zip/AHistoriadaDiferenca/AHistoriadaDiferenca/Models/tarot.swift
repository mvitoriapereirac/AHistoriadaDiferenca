//
//  File.swift
//  AHistoriadaDiferenca
//
//  Created by mvitoriapereirac on 17/05/22.
//

import Foundation

class tarot{
    let imagem: String!
    let carta: String!
    
    init(imagem: String, carta: String){
        self.carta = carta
        self.imagem = imagem

    }
}
