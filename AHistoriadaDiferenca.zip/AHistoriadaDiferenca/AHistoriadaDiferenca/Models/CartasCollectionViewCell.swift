//
//  CollectionViewCell.swift
//  AHistoriadaDiferenca
//
//  Created by mvitoriapereirac on 17/05/22.
//

import UIKit

class CartasCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var CartaImagem: UIImageView!
    @IBOutlet weak var CartaView: UIView!
    @IBOutlet weak var botaoCarta: UIButton!
    @IBOutlet weak var NomeCarta: UILabel!
    
}
       
    
